const img1 = document.getElementById('path1');
const img2 = document.getElementById('path2');
const text = document.getElementById('boxtext');
const no = document.getElementById('no');
const boxno = document.getElementById('boxno');

window.addEventListener('scroll', function(){
    let value = window.scrollY;

    img1.style.left = value * -0.55 + 0 + 'px';
    img2.style.right = value * -0.55 + 'px';
    text.style.top = value * 0.8 + 'px';
})

no.addEventListener('click', function(){
    boxno.style.display = 'flex';
    boxno.style.left = '15%'
});